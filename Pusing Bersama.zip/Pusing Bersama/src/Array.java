public class Array {
    public static void main(String[] args) throws Exception {
       String[] data = ("ayam","kfc","dean");
    //    nama = new String[5]; 
    //    nama[0] = "Dean";
    //    nama[1] = "AA";
    //    nama[2] = "BB";

       System.out.print(data[]);
    }
}