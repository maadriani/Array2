public class Contoh {
    public static void main(String[] args) {
      String[] tif = {"kittoy", "Dean", "Asep"};
      for(int a = 0; a < tif.length; a++){
        System.out.println("Kata ke-"+a+":"+tif[a]);
      }  
    }
}