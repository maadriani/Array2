import java.util.Scanner;

public class Tugas {
    public static void main(String[] args) {
        String[] kata = new String[6];
        //input
        Scanner scan = new Scanner(System.in);

        //Data array
        for(int i = 1; i < kata.length; i++){
            System.out.print("Kata Ke-" + i + ":");
            kata[i] = scan.nextLine();
        }
        System.out.println("=========================");

        //ouput
        for(String b : kata){
            System.out.print(b);
        }
    }
}
