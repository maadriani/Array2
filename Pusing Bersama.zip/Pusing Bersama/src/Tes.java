public class Tes {
    public static void main(String[] args) throws Exception {
        String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
        for (String p : cars) {
          System.out.println(p);
        }
    }
}